package com.company;

public class OutofRangeException extends Throwable {
    public OutofRangeException(String message) {
        super(message);
    }
}
