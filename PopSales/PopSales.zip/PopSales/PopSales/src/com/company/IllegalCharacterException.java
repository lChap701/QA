package com.company;

public class IllegalCharacterException extends Exception {
    public IllegalCharacterException (String message){
        super(message);
    }
}
