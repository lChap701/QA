package com.company;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PopSaleTest {

    @org.junit.jupiter.api.Test
    void setLastName() throws IllegalCharacterException {
        String lastName = "Test";
        PopSale instance = new PopSale();
        instance.setLastName(lastName);
        assertEquals(instance.getLastName(), lastName);
    }

    @org.junit.jupiter.api.Test
    void setFirstName() {
    }

    @org.junit.jupiter.api.Test
    void setAddress() {
    }

    @org.junit.jupiter.api.Test
    void setCity() {
    }

    @org.junit.jupiter.api.Test
    void setState() {
    }

    @org.junit.jupiter.api.Test
    void setZip() {
    }

    @org.junit.jupiter.api.Test
    void setPopType() {
    }

    @org.junit.jupiter.api.Test
    void setQuantity() {
    }

    @org.junit.jupiter.api.Test
    void setTeamCode() {
    }

    @Test
    void testSetLastName() {
    }

    @Test
    void getFirstName() {
    }

    @Test
    void testSetFirstName() {
    }

    @Test
    void testSetCity() {
    }

    @Test
    void testSetState() {
    }

    @Test
    void testSetZip() {
    }

    @Test
    void testSetPopType() {
    }

    @Test
    void testSetPopType1() {
    }

    @Test
    void testSetQuantity() {
    }

    @Test
    void testSetQuantity1() {
    }

    @Test
    void testSetTeamCode() {
    }

    @Test
    void testSetTeamCode1() {
    }

    @Test
    void getDepositAmnt() {
    }

    @Test
    void getSaleAmnt() {
    }

    @Test
    void getPopName() {
    }
}